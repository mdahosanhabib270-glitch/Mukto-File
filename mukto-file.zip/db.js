import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbPath = path.join(__dirname, 'mukto_file.db');
const db = new DatabaseSync(dbPath);

// Initialize schema with site_settings table for full admin control
db.exec(`
  CREATE TABLE IF NOT EXISTS resources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    title_en TEXT,
    category TEXT NOT NULL,
    category_name_bn TEXT NOT NULL,
    description TEXT NOT NULL,
    file_type TEXT NOT NULL,
    file_size TEXT NOT NULL,
    file_url TEXT NOT NULL,
    thumbnail_url TEXT,
    download_count INTEGER DEFAULT 0,
    is_featured INTEGER DEFAULT 0,
    author TEXT DEFAULT 'মুক্ত ফাইল টিম',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS donations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    donor_name TEXT NOT NULL,
    method TEXT NOT NULL,
    trx_id TEXT NOT NULL UNIQUE,
    amount INTEGER NOT NULL,
    cause_amount INTEGER NOT NULL,
    status TEXT DEFAULT 'verified',
    note TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS good_cause_expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    voucher_no TEXT NOT NULL,
    title TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'শিক্ষা উপকরণ',
    beneficiary TEXT NOT NULL,
    amount INTEGER NOT NULL,
    date TEXT NOT NULL,
    description TEXT NOT NULL,
    items_breakdown TEXT,
    receipt_img TEXT,
    field_img TEXT,
    verifier_name TEXT DEFAULT 'অডিট কমিটি, মুক্ত ফাইল',
    proof_tag TEXT DEFAULT 'যাচাইকৃত ক্যাশ মেমো',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS assistance_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    applicant_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    institution TEXT NOT NULL,
    purpose TEXT NOT NULL,
    amount_needed INTEGER NOT NULL,
    details TEXT NOT NULL,
    status TEXT DEFAULT 'পর্যালোচনাধীন',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS site_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`);

// Initialize default site settings if not present
const defaultSettings = [
  ['bkash_number', '01712-345678'],
  ['nagad_number', '01712-345678'],
  ['rocket_number', '01712-345678-0'],
  ['contact_email', 'contact@muktofile.org'],
  ['contact_phone', '+880 1712-345678'],
  ['facebook_url', 'https://facebook.com'],
  ['youtube_url', 'https://youtube.com'],
  ['github_url', 'https://github.com'],
  ['telegram_url', 'https://t.me/muktofile'],
  ['announcement_text', 'সবার জন্য সম্পূর্ণ উন্মুক্ত ডিজিটাল ফাইল ও জ্ঞানভাণ্ডার']
];

const checkSetting = db.prepare('SELECT value FROM site_settings WHERE key = ?');
const insertSetting = db.prepare('INSERT OR REPLACE INTO site_settings (key, value) VALUES (?, ?)');

for (const [key, value] of defaultSettings) {
  const existing = checkSetting.get(key);
  if (!existing) {
    insertSetting.run(key, value);
  }
}

export function getSettings() {
  const rows = db.prepare('SELECT key, value FROM site_settings').all();
  const settings = {};
  for (const row of rows) {
    settings[row.key] = row.value;
  }
  return settings;
}

export function updateSetting(key, value) {
  db.prepare('INSERT OR REPLACE INTO site_settings (key, value) VALUES (?, ?)').run(key, String(value));
}

export default db;
