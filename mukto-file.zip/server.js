import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import multer from 'multer';
import fs from 'node:fs';
import db, { getSettings, updateSetting } from './db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';

// Setup directories for uploads
const uploadsDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, `${uniqueSuffix}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 }
});

// Middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Cookie parser middleware
app.use((req, res, next) => {
  req.cookies = {};
  const cookieHeader = req.headers.cookie;
  if (cookieHeader) {
    cookieHeader.split(';').forEach(cookie => {
      const parts = cookie.split('=');
      req.cookies[parts[0].trim()] = (parts[1] || '').trim();
    });
  }
  next();
});

// View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Site Stats Helper
function getSiteStats() {
  const resourceStats = db.prepare('SELECT COUNT(*) as total, COALESCE(SUM(download_count), 0) as downloads FROM resources').get();
  const donationStats = db.prepare("SELECT COALESCE(SUM(amount), 0) as totalCollected, COALESCE(SUM(cause_amount), 0) as allocated FROM donations WHERE status = 'verified'").get();
  const expenseStats = db.prepare('SELECT COALESCE(SUM(amount), 0) as totalSpent, COUNT(*) as events FROM good_cause_expenses').get();

  const totalCollected = donationStats.totalCollected || 0;
  const allocatedToCause = donationStats.allocated || 0;
  const totalSpent = expenseStats.totalSpent || 0;
  const fundBalance = Math.max(0, allocatedToCause - totalSpent);

  return {
    totalResources: resourceStats.total || 0,
    totalDownloads: resourceStats.downloads || 0,
    totalCollected,
    allocatedToCause,
    totalSpent,
    fundBalance,
    helpedPeople: 35 + (expenseStats.events * 25)
  };
}

// Category mappings
const categoryNames = {
  books: 'বই ও ইবুক',
  dev: 'কোডিং ও ডেভ',
  templates: 'টেমপ্লেট ও ডিজাইন',
  software: 'সফটওয়্যার ও টুলস',
  career: 'ক্যারিয়ার ও স্টাডি'
};

// Admin authentication middleware
function requireAdmin(req, res, next) {
  if (req.cookies.mf_admin_auth === 'authenticated_valid_token') {
    return next();
  }
  res.redirect('/admin/login');
}

// ==================== USER PUBLIC ROUTES ====================

// Homepage
app.get('/', (req, res) => {
  const stats = getSiteStats();
  const settings = getSettings();
  const featuredResources = db.prepare('SELECT * FROM resources ORDER BY is_featured DESC, download_count DESC LIMIT 8').all();
  const recentExpenses = db.prepare('SELECT * FROM good_cause_expenses ORDER BY id DESC LIMIT 3').all();

  res.render('index', {
    stats,
    settings,
    featuredResources,
    recentExpenses
  });
});

// Resource Library
app.get('/resources', (req, res) => {
  const { category, search } = req.query;
  const settings = getSettings();
  let query = 'SELECT * FROM resources WHERE 1=1';
  const params = [];

  if (category && category !== 'all') {
    query += ' AND category = ?';
    params.push(category);
  }

  if (search) {
    query += ' AND (title LIKE ? OR description LIKE ? OR title_en LIKE ?)';
    const term = `%${search}%`;
    params.push(term, term, term);
  }

  query += ' ORDER BY id DESC';
  const resources = db.prepare(query).all(...params);

  res.render('resources', {
    resources,
    settings,
    selectedCategory: category || 'all',
    searchQuery: search || ''
  });
});

// Good Cause & Transparency
app.get('/good-cause', (req, res) => {
  const stats = getSiteStats();
  const settings = getSettings();
  const expenses = db.prepare('SELECT * FROM good_cause_expenses ORDER BY id DESC').all();
  const donations = db.prepare("SELECT * FROM donations WHERE status = 'verified' ORDER BY id DESC LIMIT 15").all();

  res.render('good-cause', {
    stats,
    settings,
    expenses,
    donations,
    reqMessage: req.query.reqMsg || null
  });
});

// Support Project
app.get('/support', (req, res) => {
  const stats = getSiteStats();
  const settings = getSettings();
  const recentDonations = db.prepare("SELECT * FROM donations WHERE status = 'verified' ORDER BY id DESC LIMIT 8").all();

  res.render('support', {
    stats,
    settings,
    recentDonations
  });
});

// About
app.get('/about', (req, res) => {
  const settings = getSettings();
  res.render('about', { settings });
});

// Contact
app.get('/contact', (req, res) => {
  const settings = getSettings();
  res.render('contact', { settings, message: null });
});

// ==================== SEPARATE ADMIN PANEL ROUTES ====================

// Admin Login Page
app.get('/admin/login', (req, res) => {
  if (req.cookies.mf_admin_auth === 'authenticated_valid_token') {
    return res.redirect('/admin');
  }
  res.render('admin-login', { error: null });
});

// Handle Admin Login
app.post('/admin/login', (req, res) => {
  const { password } = req.body;
  if (password === ADMIN_PASSWORD) {
    res.setHeader('Set-Cookie', 'mf_admin_auth=authenticated_valid_token; Path=/; HttpOnly; SameSite=Strict');
    return res.redirect('/admin');
  }
  res.render('admin-login', { error: 'ভুল অ্যাডমিন পাসওয়ার্ড। আবার চেষ্টা করুন।' });
});

// Handle Admin Logout
app.get('/admin/logout', (req, res) => {
  res.setHeader('Set-Cookie', 'mf_admin_auth=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT');
  res.redirect('/admin/login');
});

// Dedicated Mobile-App Admin Dashboard
app.get('/admin', requireAdmin, (req, res) => {
  const stats = getSiteStats();
  const settings = getSettings();
  const resources = db.prepare('SELECT * FROM resources ORDER BY id DESC').all();
  const donations = db.prepare('SELECT * FROM donations ORDER BY id DESC').all();
  const expenses = db.prepare('SELECT * FROM good_cause_expenses ORDER BY id DESC').all();
  const assistanceRequests = db.prepare('SELECT * FROM assistance_requests ORDER BY id DESC').all();
  const messages = db.prepare('SELECT * FROM messages ORDER BY id DESC LIMIT 20').all();

  res.render('admin', {
    stats,
    settings,
    resources,
    donations,
    expenses,
    assistanceRequests,
    messages,
    message: req.query.msg || null,
    error: req.query.err || null
  });
});

// Admin Update Site Settings (Numbers, Contacts, Socials)
app.post('/admin/settings/update', requireAdmin, (req, res) => {
  try {
    const fields = [
      'bkash_number',
      'nagad_number',
      'rocket_number',
      'contact_email',
      'contact_phone',
      'facebook_url',
      'youtube_url',
      'github_url',
      'telegram_url',
      'announcement_text'
    ];

    for (const field of fields) {
      if (req.body[field] !== undefined) {
        updateSetting(field, req.body[field].trim());
      }
    }

    res.redirect('/admin?msg=সাপোর্ট নম্বর ও যোগাযোগের সকল তথ্য সফলভাবে আপডেট হয়েছে!');
  } catch (err) {
    console.error('Settings error:', err);
    res.redirect('/admin?err=সেটিংস সংরক্ষণে সমস্যা হয়েছে।');
  }
});

// Admin Add Resource with File AND Referral Image
app.post(
  '/admin/resource/add',
  requireAdmin,
  upload.fields([
    { name: 'file', maxCount: 1 },
    { name: 'thumbnail', maxCount: 1 }
  ]),
  (req, res) => {
    try {
      const { title, title_en, category, file_type, file_url, thumbnail_url, description, author, is_featured } = req.body;

      let finalFileUrl = file_url ? file_url.trim() : '';
      let finalThumbnailUrl = thumbnail_url ? thumbnail_url.trim() : '';
      let fileSize = '1.2 MB';

      if (req.files && req.files.file && req.files.file[0]) {
        const uploadedFile = req.files.file[0];
        finalFileUrl = `/uploads/${uploadedFile.filename}`;
        const sizeMB = (uploadedFile.size / (1024 * 1024)).toFixed(1);
        fileSize = sizeMB > 0.1 ? `${sizeMB} MB` : `${Math.round(uploadedFile.size / 1024)} KB`;
      }

      if (req.files && req.files.thumbnail && req.files.thumbnail[0]) {
        finalThumbnailUrl = `/uploads/${req.files.thumbnail[0].filename}`;
      }

      if (!title || !description) {
        return res.redirect('/admin?err=শিরোনাম এবং বিবরণ পূরণ করা আবশ্যক।');
      }

      if (!finalFileUrl) {
        finalFileUrl = '/uploads/sample-js-guide.pdf';
      }

      const categoryNameBn = categoryNames[category] || 'সাধারণ ফাইল';

      const insertStmt = db.prepare(`
        INSERT INTO resources (title, title_en, category, category_name_bn, description, file_type, file_size, file_url, thumbnail_url, is_featured, author)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      insertStmt.run(
        title,
        title_en || title,
        category,
        categoryNameBn,
        description,
        file_type || 'PDF',
        fileSize,
        finalFileUrl,
        finalThumbnailUrl || null,
        is_featured ? 1 : 0,
        author || 'মুক্ত ফাইল টিম'
      );

      res.redirect('/admin?msg=নতুন ফাইল ও রেফারেল ইমেজ সফলভাবে যুক্ত হয়েছে!');
    } catch (err) {
      console.error('Admin upload error:', err);
      res.redirect('/admin?err=ফাইল সংরক্ষণে সমস্যা হয়েছে।');
    }
  }
);

// Admin Delete Resource
app.post('/admin/resource/:id/delete', requireAdmin, (req, res) => {
  const { id } = req.params;
  db.prepare('DELETE FROM resources WHERE id = ?').run(id);
  res.redirect('/admin?msg=রিসোর্সটি সফলভাবে মুছে ফেলা হয়েছে।');
});

// Admin Add Realistic Expense with Proofs
app.post(
  '/admin/expense/add',
  requireAdmin,
  upload.fields([
    { name: 'receipt_file', maxCount: 1 },
    { name: 'field_file', maxCount: 1 }
  ]),
  (req, res) => {
    try {
      const { title, category, beneficiary, amount, date, description, items_breakdown, proof_tag, verifier_name } = req.body;

      let receiptUrl = '/images/voucher-sample.svg';
      let fieldUrl = '/images/handover-sample.svg';

      if (req.files && req.files.receipt_file && req.files.receipt_file[0]) {
        receiptUrl = `/uploads/${req.files.receipt_file[0].filename}`;
      }

      if (req.files && req.files.field_file && req.files.field_file[0]) {
        fieldUrl = `/uploads/${req.files.field_file[0].filename}`;
      }

      const voucherNo = 'VCH-' + new Date().getFullYear() + '-' + Math.floor(1000 + Math.random() * 9000);

      db.prepare(`
        INSERT INTO good_cause_expenses (voucher_no, title, category, beneficiary, amount, date, description, items_breakdown, receipt_img, field_img, verifier_name, proof_tag)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        voucherNo,
        title,
        category || 'শিক্ষা উপকরণ',
        beneficiary || 'সাধারণ শিক্ষার্থী',
        parseInt(amount) || 0,
        date || '২০ নভেম্বর ২০২৬',
        description || '',
        items_breakdown || 'বিস্তারিত ক্যাশ মেমো সংরক্ষিত',
        receiptUrl,
        fieldUrl,
        verifier_name || 'তহবিল অডিট কমিটি',
        proof_tag || 'যাচাইকৃত ক্যাশ মেমো'
      );

      res.redirect('/admin?msg=বাস্তব ক্যাশ মেমো ও অডিট ভাউচার সহ খরচ সফলভাবে রেকর্ড করা হয়েছে!');
    } catch (err) {
      console.error('Expense error:', err);
      res.redirect('/admin?err=খরচ এন্ট্রি করতে সমস্যা হয়েছে।');
    }
  }
);

// Admin Delete Expense
app.post('/admin/expense/:id/delete', requireAdmin, (req, res) => {
  const { id } = req.params;
  db.prepare('DELETE FROM good_cause_expenses WHERE id = ?').run(id);
  res.redirect('/admin?msg=খরচ রেকর্ডটি মুছে ফেলা হয়েছে।');
});

// Admin Delete Assistance Request
app.post('/admin/request/:id/delete', requireAdmin, (req, res) => {
  const { id } = req.params;
  db.prepare('DELETE FROM assistance_requests WHERE id = ?').run(id);
  res.redirect('/admin?msg=আবেদনটি সফলভাবে মুছে ফেলা হয়েছে।');
});

// Admin Update Assistance Request Status
app.post('/admin/request/:id/status', requireAdmin, (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  db.prepare('UPDATE assistance_requests SET status = ? WHERE id = ?').run(status || 'approved', id);
  res.redirect('/admin?msg=আবেদনের স্ট্যাটাস সফলভাবে আপডেট হয়েছে।');
});

// Admin Delete Donation
app.post('/admin/donation/:id/delete', requireAdmin, (req, res) => {
  const { id } = req.params;
  db.prepare('DELETE FROM donations WHERE id = ?').run(id);
  res.redirect('/admin?msg=অনুদান রেকর্ডটি মুছে ফেলা হয়েছে।');
});

// Admin Delete Message
app.post('/admin/message/:id/delete', requireAdmin, (req, res) => {
  const { id } = req.params;
  db.prepare('DELETE FROM messages WHERE id = ?').run(id);
  res.redirect('/admin?msg=বার্তাটি মুছে ফেলা হয়েছে।');
});

// ==================== PUBLIC API ENDPOINTS ====================

// Public Assistance Request Application
app.post('/api/assistance-request', (req, res) => {
  try {
    const { applicant_name, phone, institution, purpose, amount_needed, details } = req.body;
    if (applicant_name && phone && purpose) {
      db.prepare(`
        INSERT INTO assistance_requests (applicant_name, phone, institution, purpose, amount_needed, details)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(
        applicant_name,
        phone,
        institution || '',
        purpose,
        parseInt(amount_needed) || 0,
        details || ''
      );
      return res.redirect('/good-cause?reqMsg=আপনার আবেদনটি সফলভাবে জমা হয়েছে। আমাদের তহবিল কমিটি যাচাই করে আপনার সাথে যোগাযোগ করবে।');
    }
    res.redirect('/good-cause?reqMsg=সব তথ্য সঠিকভাবে পূরণ করুন।');
  } catch (err) {
    console.error('Assistance request error:', err);
    res.redirect('/good-cause?reqMsg=আবেদন জমা নিতে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
  }
});

// Record Download Count
app.post('/api/resources/:id/download', (req, res) => {
  const { id } = req.params;
  const updateStmt = db.prepare('UPDATE resources SET download_count = download_count + 1 WHERE id = ?');
  updateStmt.run(id);

  const updated = db.prepare('SELECT download_count FROM resources WHERE id = ?').get(id);
  res.json({ success: true, count: updated ? updated.download_count : 0 });
});

// Direct Download File by Resource ID
app.get('/api/resources/:id/download', (req, res) => {
  const { id } = req.params;
  const resource = db.prepare('SELECT * FROM resources WHERE id = ?').get(id);

  if (!resource) {
    return res.status(404).send('রিসোর্সটি পাওয়া যায়নি।');
  }

  db.prepare('UPDATE resources SET download_count = download_count + 1 WHERE id = ?').run(id);

  if (resource.file_url.startsWith('/uploads/')) {
    const filePath = path.join(__dirname, 'public', resource.file_url);
    if (fs.existsSync(filePath)) {
      return res.download(filePath, `${resource.title}.${resource.file_type.toLowerCase()}`);
    }
  }

  res.redirect(resource.file_url);
});

// Public Support Submission Handler
app.post('/api/support', (req, res) => {
  try {
    const { donor_name, method, trx_id, amount, note } = req.body;

    if (!donor_name || !trx_id || !amount || amount <= 0) {
      return res.status(400).json({ success: false, error: 'সকল প্রয়োজনীয় তথ্য সঠিকভাবে পূরণ করুন।' });
    }

    const causeAmount = Math.round(amount * 0.1);

    const insertStmt = db.prepare(`
      INSERT INTO donations (donor_name, method, trx_id, amount, cause_amount, status, note)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    insertStmt.run(donor_name, method || 'bKash', trx_id, amount, causeAmount, 'verified', note || '');

    res.json({
      success: true,
      message: 'সাপোর্ট সফলভাবে রেকর্ড করা হয়েছে। ১০% মেধা তহবিলে যুক্ত হয়েছে।'
    });
  } catch (err) {
    console.error('Support submission error:', err);
    res.status(500).json({ success: false, error: 'ডাটাবেসে সংরক্ষণে সমস্যা হয়েছে।' });
  }
});

// Contact Message Submission
app.post('/api/contact', (req, res) => {
  const { name, email, message } = req.body;
  const settings = getSettings();
  if (name && email && message) {
    db.prepare('INSERT INTO messages (name, email, message) VALUES (?, ?, ?)').run(name, email, message);
  }
  res.render('contact', { settings, message: 'আপনার বার্তা পেয়েছি! শীঘ্রই আমরা আপনার সাথে যোগাযোগ করব।' });
});

// Start Server
app.listen(PORT, () => {
  console.log(`\n🚀 মুক্ত ফাইল (Mukto File) সার্ভার চালু হয়েছে!`);
  console.log(`🌐 ভিজিটর সাইট: http://localhost:${PORT}`);
  console.log(`🔐 আলাদা অ্যাডমিন প্যানেল: http://localhost:${PORT}/admin (পাসওয়ার্ড: admin123)\n`);
});
