// Theme Management
function initTheme() {
  const savedTheme = localStorage.getItem('mf-theme') || 'light';
  document.documentElement.dataset.theme = savedTheme;
  updateThemeIcon(savedTheme);
}

function toggleTheme() {
  const current = document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light';
  const nextTheme = current === 'dark' ? 'light' : 'dark';
  document.documentElement.dataset.theme = nextTheme;
  localStorage.setItem('mf-theme', nextTheme);
  updateThemeIcon(nextTheme);
}

function updateThemeIcon(theme) {
  const icons = document.querySelectorAll('.theme-toggle-icon');
  icons.forEach(el => {
    if (theme === 'dark') {
      // Sun icon
      el.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>`;
    } else {
      // Moon icon
      el.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401"/></svg>`;
    }
  });
}

// Language Switcher
function toggleLanguage() {
  const currentLang = localStorage.getItem('mf-lang') || 'bn';
  const newLang = currentLang === 'bn' ? 'en' : 'bn';
  localStorage.setItem('mf-lang', newLang);
  applyLanguage(newLang);
}

function applyLanguage(lang) {
  const langBtns = document.querySelectorAll('.lang-toggle-btn');
  langBtns.forEach(btn => {
    btn.textContent = lang === 'bn' ? 'EN' : 'বাং';
  });

  const bnElements = document.querySelectorAll('.lang-bn');
  const enElements = document.querySelectorAll('.lang-en');

  if (lang === 'en') {
    bnElements.forEach(el => el.classList.add('hidden'));
    enElements.forEach(el => el.classList.remove('hidden'));
  } else {
    bnElements.forEach(el => el.classList.remove('hidden'));
    enElements.forEach(el => el.classList.add('hidden'));
  }
}

// Copy to Clipboard
function copyToClipboard(text, element) {
  navigator.clipboard.writeText(text).then(() => {
    const originalText = element.getAttribute('data-original-text') || element.innerText;
    element.setAttribute('data-original-text', originalText);
    element.innerHTML = '✓ কপি হয়েছে!';
    element.classList.add('text-ok');
    setTimeout(() => {
      element.innerHTML = originalText;
      element.classList.remove('text-ok');
    }, 2000);
  });
}

// Download Modal Handling
let currentDownloadUrl = '';
let currentResourceId = null;

function openDownloadModal(id, title, size, format, url) {
  currentDownloadUrl = url;
  currentResourceId = id;

  const modal = document.getElementById('downloadModal');
  const modalTitle = document.getElementById('modalFileTitle');
  const modalMeta = document.getElementById('modalFileMeta');
  const startBtn = document.getElementById('modalStartDownloadBtn');

  if (modalTitle) modalTitle.textContent = title;
  if (modalMeta) modalMeta.textContent = `${format} • ${size}`;

  if (modal) {
    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }

  // Auto trigger download counter
  let seconds = 3;
  if (startBtn) {
    startBtn.disabled = true;
    startBtn.innerHTML = `ডাউনলোড তৈরি হচ্ছে (${seconds}s)...`;
    const interval = setInterval(() => {
      seconds--;
      if (seconds > 0) {
        startBtn.innerHTML = `ডাউনলোড তৈরি হচ্ছে (${seconds}s)...`;
      } else {
        clearInterval(interval);
        startBtn.disabled = false;
        startBtn.innerHTML = `এখনই ডাউনলোড করুন (Direct Link)`;
        triggerDirectDownload();
      }
    }, 1000);
  }
}

function triggerDirectDownload() {
  if (currentResourceId) {
    // Record download on backend
    fetch(`/api/resources/${currentResourceId}/download`, { method: 'POST' }).catch(console.error);

    // Update count in UI if on page
    const countEl = document.getElementById(`count-${currentResourceId}`);
    if (countEl) {
      let current = parseInt(countEl.textContent.replace(/[^0-9]/g, '')) || 0;
      countEl.textContent = `${current + 1}`;
    }
  }

  if (currentDownloadUrl) {
    const a = document.createElement('a');
    a.href = currentDownloadUrl;
    a.download = '';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
}

function closeDownloadModal() {
  const modal = document.getElementById('downloadModal');
  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }
}

// Support Submission Form
async function submitSupportForm(event) {
  event.preventDefault();
  const form = event.target;
  const statusEl = document.getElementById('supportFormStatus');
  const submitBtn = form.querySelector('button[type="submit"]');

  const formData = {
    donor_name: form.donor_name.value.trim(),
    method: form.method.value,
    trx_id: form.trx_id.value.trim(),
    amount: parseInt(form.amount.value) || 0,
    note: form.note ? form.note.value.trim() : ''
  };

  if (!formData.donor_name || !formData.trx_id || formData.amount <= 0) {
    statusEl.innerHTML = '<span class="text-danger">দয়া করে নাম, ট্রানজেকশন আইডি এবং সঠিক টাকার পরিমাণ লিখুন।</span>';
    return;
  }

  submitBtn.disabled = true;
  submitBtn.innerText = 'যাচাই করা হচ্ছে...';

  try {
    const res = await fetch('/api/support', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });
    const data = await res.json();

    if (data.success) {
      statusEl.innerHTML = `<div class="p-4 rounded-2xl bg-ok/12 text-ok border border-ok/30">
        ❤️ ধন্যবাদ ${formData.donor_name}! আপনার ট্রানজেকশন সফলভাবে জমা হয়েছে। ১০% (৳${Math.round(formData.amount * 0.1)}) ভালো কাজের ফান্ডে যোগ হয়েছে।
      </div>`;
      form.reset();
      setTimeout(() => {
        window.location.reload();
      }, 2500);
    } else {
      statusEl.innerHTML = `<span class="text-danger">${data.error || 'জমা নিতে সমস্যা হয়েছে।'}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = '<span class="text-danger">সার্ভারের সাথে যোগাযোগ করা যাচ্ছে না। আবার চেষ্টা করুন।</span>';
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerText = 'সাপোর্ট কনফার্ম করুন';
  }
}

// Live Search & Category Filter for Resources
function filterResources() {
  const searchInput = document.getElementById('resourceSearch');
  const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
  const activeCategory = document.querySelector('.category-tab.active')?.getAttribute('data-cat') || 'all';

  const cards = document.querySelectorAll('.resource-card');
  let visibleCount = 0;

  cards.forEach(card => {
    const cardCategory = card.getAttribute('data-category');
    const cardTitle = card.getAttribute('data-title').toLowerCase();
    const cardDesc = card.getAttribute('data-desc').toLowerCase();

    const matchesCategory = activeCategory === 'all' || cardCategory === activeCategory;
    const matchesSearch = !query || cardTitle.includes(query) || cardDesc.includes(query);

    if (matchesCategory && matchesSearch) {
      card.style.display = 'flex';
      visibleCount++;
    } else {
      card.style.display = 'none';
    }
  });

  const emptyState = document.getElementById('emptyState');
  if (emptyState) {
    emptyState.style.display = visibleCount === 0 ? 'block' : 'none';
  }
}

function selectCategory(btn, category) {
  document.querySelectorAll('.category-tab').forEach(b => {
    b.classList.remove('active', 'bg-ink', 'text-ink-fg');
    b.classList.add('glass', 'text-fg');
  });

  btn.classList.add('active', 'bg-ink', 'text-ink-fg');
  btn.classList.remove('glass');
  filterResources();
}

// Run on page load
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  const savedLang = localStorage.getItem('mf-lang') || 'bn';
  applyLanguage(savedLang);

  const searchInput = document.getElementById('resourceSearch');
  if (searchInput) {
    searchInput.addEventListener('input', filterResources);
  }
});
